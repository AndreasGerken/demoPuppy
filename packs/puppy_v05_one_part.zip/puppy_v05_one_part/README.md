# puppy_V05

This version uses the following parts:
- One part body:           With mounting holes for the Arduino Mega
- imu holder:              Holder for the imu MPU 6050
- 4x Servo holder CS-3:    Holders for the Carson CS-3 Servos
- 4x Flexible Legs:        With mounting holes for Carson CS-3 horn

PLA parts
- 0.1 Layer Height
- Support Structure
- PLA (we used Form Futura EasyFillPLA)
- Orient the body to easily remove support
- Aproximately 10m Material
- 750g roll costs 24€ and has 168m ->10m = 1,43€
https://rigid.ink/blogs/news/how-many-meters-of-filament-on-a-spool

